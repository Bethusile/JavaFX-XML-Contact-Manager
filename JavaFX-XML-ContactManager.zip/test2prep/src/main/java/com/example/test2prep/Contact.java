package com.example.test2prep;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Contact extends Application {

    protected Scene createScene() {
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label name = new Label("Name:");
        TextField entername = new TextField("");
        entername.setId("name");

        Label number = new Label("Cell:");
        TextField enternumber = new TextField("");
        enternumber.setId("number");

        Label counter = new Label("X of Y");
        counter.setAlignment(Pos.CENTER);
        counter.setId("counter");

        Button prev = new Button("<<");
        prev.setId("prev");

        Button add = new Button("+");
        add.setId("add");

        Button next = new Button(">>");
        next.setId("next");

        Button load = new Button("load");
        load.setId("load");

        Button save = new Button("save");
        save.setId("save");

        Button delete = new Button("delete");
        delete.setId("delete");

        HBox buttons = new HBox(10, prev, add, next, load, save, delete);
        buttons.setAlignment(Pos.CENTER);

        root.getChildren().addAll(name, entername, number, enternumber, counter, buttons);

        ContactController controller = new ContactController();
        controller.setUI(entername, enternumber, counter, prev, next, add, delete, load, save);

        return new Scene(root, 300, 200);
    }

    @Override
    public void start(Stage stage) {
        stage.setScene(createScene());
        stage.setTitle("Contacts from XML");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
