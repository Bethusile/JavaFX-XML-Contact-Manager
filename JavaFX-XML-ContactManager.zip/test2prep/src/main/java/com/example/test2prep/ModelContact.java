package com.example.test2prep;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ModelContact{
    private StringProperty name = new SimpleStringProperty();
    private StringProperty number = new SimpleStringProperty();

    public ModelContact (String name , String number){
        this.name.set(name);
        this.number.set(number);
    }
    public StringProperty getNameProp(){
        return name;
    }
    public StringProperty getNumberProp(){
        return number;
    }
    public String toString(){
        return String.format(name.getValue(), number.getValue());
    }
}
