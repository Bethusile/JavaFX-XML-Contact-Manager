package com.example.test2prep;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.ArrayList;

public class ContactController {
    // UI elements (provided by the view)
    private TextField nameField;
    private TextField numberField;
    private Label counterLabel;

    private Button prevButton;
    private Button nextButton;
    private Button addButton;
    private Button deleteButton;
    private Button loadButton;
    private Button saveButton;

    // Contact list
    private List<ModelContact> contacts = new ArrayList<>();
    private int currentIndex = -1; // no contact loaded yet

    // Method to wire the UI
    public void setUI(TextField nameField, TextField numberField, Label counterLabel,
                      Button prevButton, Button nextButton, Button addButton,
                      Button deleteButton, Button loadButton, Button saveButton) {
        this.nameField = nameField;
        this.numberField = numberField;
        this.counterLabel = counterLabel;

        this.prevButton = prevButton;
        this.nextButton = nextButton;
        this.addButton = addButton;
        this.deleteButton = deleteButton;
        this.loadButton = loadButton;
        this.saveButton = saveButton;

        Initialize();
    }
    private void Initialize(){
        loadButton.setOnAction(e->loadXML());
        nextButton.setOnAction(e->showNext());
        prevButton.setOnAction(e->showPrev());
        addButton.setOnAction(e->addContact());
        deleteButton.setOnAction(e->delete());
        saveButton.setOnAction(e->{
                File file = new File("contacts-out.xml");
                save(file);
        });
    }

    private void displayContact(int index) {
        if (index >= 0 && index < contacts.size()) {
            ModelContact contact = contacts.get(index);
            nameField.setText(contact.getNameProp().get());
            numberField.setText(contact.getNumberProp().get());
            counterLabel.setText((index + 1) + " of " + contacts.size());
        }
    }

    private void showNext(){
        if (currentIndex < contacts.size() - 1) {
            currentIndex++;
            displayContact(currentIndex);
        }
    }
    private void showPrev(){
        if (currentIndex > 0) {
            currentIndex--;
            displayContact(currentIndex);
        }
    }
    private void addContact(){
        String name = nameField.getText().trim();
        String number = numberField.getText().trim();

        if (!name.isEmpty() && !number.isEmpty()) {
            ModelContact newContact = new ModelContact(name, number);
            contacts.add(newContact);
            currentIndex = contacts.size() - 1; // go to the newly added contact
            displayContact(currentIndex);
        }

    }
    private void delete(){
        if (!contacts.isEmpty() && currentIndex >= 0) {
            contacts.remove(currentIndex);

            if (contacts.isEmpty()) {
                nameField.clear();
                numberField.clear();
                counterLabel.setText("0 of 0");
                currentIndex = -1;
            } else {
                if (currentIndex >= contacts.size()) {
                    currentIndex = contacts.size() - 1;
                }
                displayContact(currentIndex);
            }
        }
    }
    private void loadXML() {
        contacts.clear();
        currentIndex = -1;

        try {
            File file = new File("contacts.xml");
            if (!file.exists()) {
                System.out.println("contacts.xml not found!");
                return;
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);

            NodeList contactNodes = doc.getElementsByTagName("contact");
            for (int i = 0; i < contactNodes.getLength(); i++) {
                Element contactElement = (Element) contactNodes.item(i);
                String name = contactElement.getElementsByTagName("name").item(0).getTextContent();
                String number = contactElement.getElementsByTagName("contactNumber").item(0).getTextContent();
                contacts.add(new ModelContact(name, number));
            }

            if (!contacts.isEmpty()) {
                currentIndex = 0;
                displayContact(currentIndex);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void save(File file) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.newDocument();

            Element rootElement = doc.createElement("contacts");
            doc.appendChild(rootElement);

            for (ModelContact contact : contacts) {
                Element contactElement = doc.createElement("contact");

                Element nameElement = doc.createElement("name");
                nameElement.setTextContent(contact.getNameProp().get());
                contactElement.appendChild(nameElement);

                Element numberElement = doc.createElement("contactNumber");
                numberElement.setTextContent(contact.getNumberProp().get());
                contactElement.appendChild(numberElement);

                rootElement.appendChild(contactElement);
            }

            // Save to file using DOM LS
            DOMImplementation impl = doc.getImplementation();
            DOMImplementationLS implLS = (DOMImplementationLS) impl.getFeature("LS", "3.0");
            LSSerializer serializer = implLS.createLSSerializer();
            serializer.getDomConfig().setParameter("format-pretty-print", true);

            LSOutput output = implLS.createLSOutput();
            output.setEncoding("UTF-8");
            output.setByteStream(new FileOutputStream(file));

            serializer.write(doc, output);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
